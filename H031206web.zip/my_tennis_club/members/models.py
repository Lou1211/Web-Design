from django.db import models

class Member(models.Model):
  firstname = models.CharField(max_length=255)
  lastname = models.CharField(max_length=255)
  age = models.IntegerField(null=True)
  phone = models.IntegerField(null=True)
  joined_date = models.DateField(null=True)

class Place(models.Model):
  name = models.CharField(max_length=255)
  at = models.CharField(max_length=255)
  GRASS = 'GR'
  HARD = 'HD'
  CLAY = 'CY'
  CARPET = 'CP'
  GTYPE_CHOICES = (
        (GRASS, 'Grass'),
        (HARD, 'Hard'),
        (CLAY, 'Clay'),
        (CARPET, 'Carpet'),
    )
  gtype = models.CharField(max_length=10, choices=GTYPE_CHOICES, default=GRASS)
  
def __str__(self):
    return f"{self.firstname} {self.lastname}"