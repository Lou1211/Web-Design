from django.urls import path
from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('members/', views.members, name='members'),
    path('members/details/<int:id>', views.details, name='details'),
    path('places/', views.place, name='place'),
    path('places/details/<int:id>', views.Pdetails, name='Pdetails'),
    path('testing/', views.testing, name='testing'),
]